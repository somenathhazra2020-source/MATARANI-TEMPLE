# JAI MATA DI — Hazra Bari Virtual Durga Mandir • VERSION 3

Advanced Replit-ready Streamlit build.

Main file: `JAI_MATA_DI_VERSION3.py`

Run:
```bash
streamlit run JAI_MATA_DI_VERSION3.py
```

Includes all Version 2/V5 features plus an Advanced Devotee Center with XP/levels, missions, milestones, analytics and quick actions; robust session refresh; full Maa-er Bhog; Panchang; temple rooms; V15 center; dashboard; admin tools; and Replit deployment configuration.

Panchang shows Tithi, Nakshatra, Paksha, Sunrise, Sunset, Moonrise and Moonset. Yoga and Karana remain hidden.

Optional Replit/Streamlit secrets:
- `ADMIN_EMAILS`
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

Do not place private service-role keys in source code.
