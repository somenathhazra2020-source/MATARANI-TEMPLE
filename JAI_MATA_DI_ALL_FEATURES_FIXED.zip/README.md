# JAI MATA DI — Hazra Bari Virtual Durga Mandir 2026

Main Streamlit entry file: `JAI_MATA_DI.py`

Merged from HAZRA BARI MANDIR V5 and HAZRA_BARI_MANDIR2. All V5 navigation/Panchang features are retained and the Maa-er Bhog Seva system is included.

Run:
```bash
streamlit run JAI_MATA_DI.py
```

Maa-er Bhog includes Khichdi, Puri, Chana, Halwa, Pulao, Rice, Dal, Luchi, Aloo Dum, Labra, vegetables, Payesh, Kheer, Sandesh, Laddoo, Rasgulla, Mishri, Banana, Coconut, fruits, Milk, Honey, Panchamrit, Chira/Chuda, Gur and a Complete Sattvik Bhog Thali.

Panchang: Tithi, Nakshatra, Paksha, Sunrise, Sunset, Moonrise and Moonset. Yoga and Karana are intentionally hidden from the UI.

Temple location: Sagarbhanga, Durgapur-11, Paschim Bardhaman, West Bengal - 713211, India.
